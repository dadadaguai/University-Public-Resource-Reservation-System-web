function transPxStr(val){
    return val + 'px'
}
export default {
    transPxStr
}