<template>
    <el-empty description="空空如也"></el-empty>
</template>

<script>
    export default {
        name:'Empty',
    }
</script>

<style scoped>

</style>